import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Video } from "lucide-react"
import Navbar from "@/components/navbar"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      <Navbar />

      <div className="flex-1 container max-w-6xl px-4 py-16 md:py-24">
        <div className="flex flex-col items-center text-center space-y-8">
          <div className="bg-blue-100 text-blue-700 px-4 py-2 rounded-full inline-flex items-center">
            <span>Introducing Content Genie</span>
          </div>

          <div className="space-y-4 max-w-4xl">
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight">AI-Powered Video Creation</h1>
            <h2 className="text-4xl md:text-6xl font-bold tracking-tight bg-gradient-to-r from-blue-400 to-purple-500 text-transparent bg-clip-text">
              From Just a Title
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto mt-6">
              Transform your ideas into professional videos in minutes. No editing skills required. Just enter a title
              and let our AI do the magic.
            </p>
          </div>

          <div className="w-full max-w-3xl aspect-video bg-gray-100 rounded-lg flex items-center justify-center my-8">
            <div className="w-20 h-20 rounded-full bg-white flex items-center justify-center shadow-md">
              <Video className="h-8 w-8 text-blue-500" />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md">
            <Button asChild className="w-full py-6 text-base font-medium">
              <Link href="/get-started">
                Get Started <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button asChild variant="outline" className="w-full py-6 text-base font-medium">
              <Link href="/demo">Watch Full Demo</Link>
            </Button>
          </div>
        </div>
      </div>
    </main>
  )
}

